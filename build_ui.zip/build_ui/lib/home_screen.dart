import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.teal,
        title: const Center(
            child: Text(
          'Navigation Drawer',
          style: TextStyle(fontFamily: 'PermanentMarker', color: Colors.white),
        )),
      ),
      body: Column(
        children: [
          TextButton(onPressed: (){}, child: Text('Screen 1',))
        ],
      ),
    );
  }
}
